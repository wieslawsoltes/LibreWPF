// Diagnostic root host. The original Gallery page, controls and handlers are unchanged.
using System.IO;
using System.Text.Json;
using System.Windows.Automation;
using System.Windows.Controls.Primitives;
using System.Windows.Threading;
using System.Windows.Media.ProGPU;
using WPFGallery.Views;
using WPFGallery.ViewModels;

internal static class GallerySliderProbe
{
    [STAThread]
    private static int Main(string[] args)
    {
        if (!OperatingSystem.IsLinux() || args.Length != 1 || !Directory.Exists(args[0]))
            throw new ArgumentException("Linux and an existing evidence directory are required.");
        string output = Path.GetFullPath(args[0]);
        Stopwatch clock = Stopwatch.StartNew();
        Application app = new();
        foreach (string resource in new[] {
            "pack://application:,,,/PresentationFramework.Fluent;component/Themes/Fluent.xaml",
            "Controls/ControlExample.xaml", "Controls/PageHeader.xaml" })
            app.Resources.MergedDictionaries.Add(new ResourceDictionary { Source = new Uri(resource, UriKind.RelativeOrAbsolute) });
        SliderPage page = new(new SliderPageViewModel());
        Window window = new() { Title = "Gallery slider input diagnostic", Width = 900, Height = 900, Content = page };
        using StreamWriter log = new(Path.Combine(output, "events.jsonl"), false) { AutoFlush = true };
        List<Slider> sliders = new();
        int events = 0;
        bool ready = false, timedOut = false;

        object PointData(Point p) => new { x = p.X, y = p.Y };
        void Record(string kind, object data)
        {
            if (++events > 4096) throw new InvalidOperationException("Diagnostic event budget exceeded.");
            log.WriteLine(JsonSerializer.Serialize(new { kind, elapsed = clock.Elapsed.TotalSeconds, data }));
        }
        object Geometry(FrameworkElement item)
        {
            Point a = item.PointToScreen(new Point(0, 0));
            Point b = item.PointToScreen(new Point(item.ActualWidth, item.ActualHeight));
            return new { name = AutomationProperties.GetName(item), sourceWidth = item.ActualWidth,
                sourceHeight = item.ActualHeight, topLeft = PointData(a), bottomRight = PointData(b) };
        }
        IEnumerable<T> Descendants<T>(DependencyObject item) where T : DependencyObject
        {
            int count = VisualTreeHelper.GetChildrenCount(item);
            for (int i = 0; i < count; i++)
            {
                DependencyObject child = VisualTreeHelper.GetChild(item, i);
                if (child is T found) yield return found;
                foreach (T nested in Descendants<T>(child)) yield return nested;
            }
        }
        object Snapshot(Slider s)
        {
            Thumb? thumb = Descendants<Thumb>(s).FirstOrDefault();
            return new { name = AutomationProperties.GetName(s), value = s.Value, minimum = s.Minimum,
                maximum = s.Maximum, tickFrequency = s.TickFrequency, snap = s.IsSnapToTickEnabled,
                slider = Geometry(s), thumb = thumb is null ? null : Geometry(thumb),
                dragging = thumb?.IsDragging, captured = thumb?.IsMouseCaptured };
        }
        window.AddHandler(Mouse.PreviewMouseMoveEvent, new MouseEventHandler((_, e) => {
            if (!ready) return;
            Record("mouse-move", new { windowPoint = PointData(e.GetPosition(window)), left = e.LeftButton.ToString(),
                sliders = sliders.Select(s => new { name = AutomationProperties.GetName(s),
                    point = PointData(e.GetPosition(s)), value = s.Value }).ToArray() });
        }), true);
        window.AddHandler(Thumb.DragStartedEvent, new DragStartedEventHandler((_, e) =>
            Record("drag-started", new { e.HorizontalOffset, e.VerticalOffset, sliders = sliders.Select(Snapshot).ToArray() })), true);
        window.AddHandler(Thumb.DragDeltaEvent, new DragDeltaEventHandler((_, e) =>
            Record("drag-delta", new { e.HorizontalChange, e.VerticalChange, sliders = sliders.Select(Snapshot).ToArray() })), true);
        window.AddHandler(Thumb.DragCompletedEvent, new DragCompletedEventHandler((_, e) =>
            Record("drag-completed", new { e.HorizontalChange, e.VerticalChange, e.Canceled, sliders = sliders.Select(Snapshot).ToArray() })), true);

        DispatcherTimer timer = new(DispatcherPriority.Background) { Interval = TimeSpan.FromMilliseconds(250) };
        timer.Tick += (_, _) => {
            if (clock.Elapsed.TotalSeconds >= 170 || File.Exists(Path.Combine(output, "stop.request")))
            {
                timedOut = clock.Elapsed.TotalSeconds >= 170;
                timer.Stop(); window.Close(); app.Shutdown(timedOut ? 2 : 0); return;
            }
            if (ready || !ProGpuWpfDiagnostics.TryGetWindowHost(window, out var host) || host is null || !host.HasPresentedFrame) return;
            sliders.AddRange(Descendants<Slider>(page));
            if (sliders.Count != 4) throw new InvalidOperationException("The original page must expose its four sliders.");
            foreach (Slider slider in sliders)
                slider.ValueChanged += (_, e) => Record("value-changed", new { name = AutomationProperties.GetName(slider), e.OldValue, e.NewValue });
            ready = true;
            object state = new { pid = Environment.ProcessId, elapsed = clock.Elapsed.TotalSeconds,
                frame = host.PresentedFrameCount, nativeKind = host.NativeWindowHandle.Kind.ToString(),
                nativeHandle = host.NativeWindowHandle.Handle.ToInt64(), sliders = sliders.Select(Snapshot).ToArray(),
                inputSynthesized = false, qualified = false };
            File.WriteAllText(Path.Combine(output, "ready.json.tmp"), JsonSerializer.Serialize(state, new JsonSerializerOptions { WriteIndented = true }));
            File.Move(Path.Combine(output, "ready.json.tmp"), Path.Combine(output, "ready.json"));
            Record("ready", state);
        };
        timer.Start();
        int result = app.Run(window);
        Record("exit", new { result, ready, timedOut });
        return result;
    }
}
