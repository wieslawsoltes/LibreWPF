from pathlib import Path, PurePosixPath
import hashlib,json,os,signal,subprocess,tempfile,time,zipfile

ROOT=Path(__file__).resolve().parent
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
receipt=json.loads((ROOT/'preparation.json').read_text());assert receipt['compiled']
assert sha(ROOT/'application.zip')==receipt['payloadArchiveSha256']
files=json.loads((ROOT/'payload-manifest.json').read_text())
stage=Path(tempfile.mkdtemp(prefix='progpu-slider-52-'))
out=ROOT/'run2-native-input';out.mkdir()
with zipfile.ZipFile(ROOT/'application.zip') as z:
    for info in z.infolist():
        rel=PurePosixPath(info.filename)
        assert not rel.is_absolute() and '..' not in rel.parts
        p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(info))
for x in files:assert sha(stage/x['path'])==x['sha256']
(stage/'GallerySliderProbe').chmod(0o700)
env=os.environ.copy()
for k in list(env):
    if k.startswith(('DOTNET_', 'ProGpu', 'PROGPU', 'LD_LIBRARY_PATH', 'NUGET_')):env.pop(k)
desktop=json.loads((ROOT/'guest-session.json').read_text());assert desktop.get('DISPLAY')
env.update(desktop);env['DOTNET_ROOT']='/usr/local/share/dotnet'
result={'stage':str(stage),'qualified':False,'inputSynthesizedByRunner':False,'deadlineSeconds':180,
        'os':Path('/etc/os-release').read_text(),'desktop':desktop,'manifestFiles':len(files)}
def save():(out/'runner.json').write_text(json.dumps(result,indent=2)+'\n')
save();started=time.monotonic()
with (out/'stdout.log').open('x') as stdout,(out/'stderr.log').open('x') as stderr:
    proc=subprocess.Popen([str(stage/'GallerySliderProbe'),str(out)],cwd=stage,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
    result.update(pid=proc.pid,startedUtc=time.time(),startedMonotonic=started);save()
    try:code=proc.wait(timeout=180)
    except subprocess.TimeoutExpired:
        result['timedOut']=True;os.killpg(proc.pid,signal.SIGTERM)
        try:code=proc.wait(timeout=5)
        except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);code=proc.wait(timeout=5)
result.update(exitCode=code,seconds=time.monotonic()-started,payloadUnchanged=all(sha(stage/x['path'])==x['sha256'] for x in files))
save();print(json.dumps(result))
